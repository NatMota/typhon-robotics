VIDEO-INFORMED SCENARIO RECONSTRUCTION FOR CONTINUOUS ROBOTIC MANIPULATION
Revised manuscript, 16 October 2026

BUILD
Run sh build.sh with Tectonic or pdfLaTeX installed. The included vector figures
are sufficient to typeset main.pdf without Python, network access, raw recordings,
model weights or a simulator (a first Tectonic installation may fetch TeX packages).

FIGURES AND SAVED-DATA ANALYSIS
Optional: install requirements-figures.txt, then run python plot_manuscript.py.
This performs only saved-data analysis and rendering, not model or robot execution.
Figure input checksums and numerical validation are in figure_data/figure_validation.json.
Primary success intervals are two-sided exact 95% binomial intervals. Secondary
paired error intervals use 10,000 percentile-bootstrap resamples of complete
scenario-seed pairs, seed 20261016. The source-family intervals for goal teaching
are read from the retained 10,000-resample summaries in evaluation-groups.json.
They describe six inspected source families and fixed fitted models. All-zero
bootstrap intervals are not plotted as certainty of zero future performance.
Every final-evaluation pair is retained, including the upstream-discrepant pair.

IMAGES
The methods figure selects original image rectangles from an archived simulator
contact sheet. The setup photograph has AI-assisted background cleanup, disclosed
in its caption. The hand-held block image is an unchanged decoded demonstration
frame, identified by source recording, frame index, timestamp and checksum in
figure_data/image_provenance.json.

MODEL NAMES
Stream, Chunks, Anchors and Repair identify temporal data choices.
Source identifies the six-source native-interface adaptation.
Fixed, Range and Recovery identify matched continuations from Source.
Switch and Retain identify loading/task-selection and preservation continuations.
The table specifies parameters updated and optimizer budgets.

SCOPE
This package reproduces the manuscript and its figures from derived measurements.
Raw media, model weights and executable research code are retained separately.
The smaller technical reports remain unchanged.
SHA256SUMS pins packaged file contents.
