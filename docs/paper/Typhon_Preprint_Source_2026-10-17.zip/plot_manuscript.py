"""Regenerate manuscript figures from saved measurements; no policy or simulator runs."""
from pathlib import Path
import csv, hashlib, json, math
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import Rectangle, FancyArrowPatch, Patch
from scipy.stats import beta

ROOT = Path(__file__).resolve().parent
DATA, OUT = ROOT/"figure_data", ROOT/"figures"
OUT.mkdir(exist_ok=True)
plt.rcParams.update({
    "font.family":"DejaVu Sans", "font.size":8.5, "axes.titlesize":10,
    "axes.labelsize":8.5, "axes.spines.top":False, "axes.spines.right":False,
    "pdf.fonttype":42, "svg.fonttype":"none", "savefig.facecolor":"white",
})
BLUE, ORANGE, TEAL, GREY = "#245c87", "#b46823", "#237a70", "#65717a"

def save(fig, name):
    for ext in ("pdf","png"):
        fig.savefig(OUT/f"{name}.{ext}", dpi=220, bbox_inches="tight")
    plt.close(fig)

def exact_ci(k,n):
    return (0. if k==0 else float(beta.ppf(.025,k,n-k+1)),
            1. if k==n else float(beta.ppf(.975,k+1,n-k)))
assert np.allclose(exact_ci(25,36),(.5189293699999202,.8365260153715064), atol=1e-12)
assert exact_ci(0,36)[0] == 0 and exact_ci(36,36)[1] == 1

# Methods plus unmodified image regions from an archived development contact sheet.
fig=plt.figure(figsize=(7.2,3.3))
ax=fig.add_axes([0,.49,1,.50]); ax.set(xlim=(0,10),ylim=(0,2.2)); ax.axis("off")
xs=[.03,2.56,5.09,7.62]; w=2.30
rows=[
 (1.18,[("Phone observations","Positions, goals, categories"),("Virtual scenarios","Virtual scale and uncertainty"),("Robot expert","Simulated RGB + actions"),("Policy adaptation","Separate model families")]),
 (.10,[("Image sequence","Object and numeral features"),("Image-based adapter","Supplied robot control"),("Visual feedback","Geometry and timing limits"),("Robot execution","Constrained manipulation")])
]
for y,boxes in rows:
    for i,(head,body) in enumerate(boxes):
        x=xs[i]
        ax.add_patch(Rectangle((x,y),w,.80,facecolor="#f1f5f7",edgecolor="#bac5cc",lw=.7))
        ax.text(x+w/2,y+.55,head,ha="center",va="center",fontsize=8.3,fontweight="bold")
        ax.text(x+w/2,y+.23,body,ha="center",va="center",fontsize=6.8)
        if i<3: ax.add_patch(FancyArrowPatch((x+w,y+.4),(xs[i+1],y+.4),arrowstyle="-|>",mutation_scale=9,color=GREY,lw=.8))
img=plt.imread(DATA/"workflow_contact_sheet.png")
h,ww=img.shape[:2]
# Image-only rectangles of the original native row; annotations outside these
# rectangles are excluded. No simulated content is altered or synthesized.
y0,y1=round(h*60/626),round(h*316/626)
for i,(col,label) in enumerate([(0,"Feeding start"),(1,"Feeding complete"),(3,"Loading complete")]):
    a=fig.add_axes([.008+i*.334,.015,.316,.425])
    x0,x1=round(ww*col/4),round(ww*(col+1)/4)
    a.imshow(img[y0:y1,x0:x1]); a.axis("off")
    a.set_title(label,fontsize=9,pad=4,fontweight="bold")
save(fig,"system")

groups=json.loads((DATA/"evaluation-groups.json").read_text())
bygroup={(x["method"],x["group"]):x for x in groups if x["panel"]=="goal"}
fig,axes=plt.subplots(1,3,figsize=(7.0,2.25),sharey=True)
for ax,group,title in zip(axes,["original_source","new_start_goal_combination","loading_transfer_no_B_labels"],
                         ["Familiar goals","New start/goal combinations","Unseen loading task"]):
    for x,method,name,color in [(0,"fixed","Fixed",GREY),(1,"varied","Range",TEAL)]:
        row=bygroup[method,group]; assert row["n"]==12
        p=row["strict_family_bootstrap"]["family_balanced_mean"]*100
        lo,hi=np.array(row["strict_family_bootstrap"]["percentile95"])*100
        if row["strict"]==0:
            ax.plot(x,0,marker="o",mfc="white",mec=color,ms=6)
        else:
            ax.errorbar(x,p,yerr=[[p-lo],[hi-p]],fmt="o",color=color,capsize=4,ms=6,lw=1.5)
        ax.text(x+.12,p+4 if p<90 else p-8,f'{row["strict"]}/12',ha="left",va="bottom",fontsize=8,color=color)
    ax.set(xlim=(-.5,1.5),ylim=(-5,110),xticks=[0,1],xticklabels=["Fixed","Range"],yticks=[0,25,50,75,100])
    ax.set_title(title,fontsize=8.8,pad=10)
    ax.grid(axis="y",color="#e6ebee",lw=.6); ax.set_axisbelow(True)
axes[0].set_ylabel("Strict completion (%)")
fig.subplots_adjust(left=.09,right=.995,bottom=.18,top=.80,wspace=.14)
save(fig,"goal_diversity")

stages=list(csv.DictReader((DATA/"recomputed_stage_scores.csv").open()))
workflows=list(csv.DictReader((DATA/"WORKFLOW_RESULTS.csv").open()))
assert len(stages)==144 and len(workflows)==72
assert all(r["status"]=="completed" for r in workflows)
pairs=sorted({r["pair_id"] for r in workflows})
assert len(pairs)==36
outcomes={(r["pair_id"],r["mode"]):r["primary_success"]=="True" for r in workflows}
assert len(outcomes)==72
s={(r["workflow"].rsplit("-",1)[0],r["condition"],r["stage"]):r for r in stages}
assert len(s)==144
cis={}
for m,k in [("N",25),("A",31)]:
    assert sum(outcomes[p,m] for p in pairs)==k
    cis[m]={"successes":k,"n":36,"estimate":k/36,"lower95":exact_ci(k,36)[0],"upper95":exact_ci(k,36)[1]}

rng=np.random.default_rng(20261016)
indices=rng.integers(0,36,size=(10000,36))
paired_stats={}
for field,mult,unit in [("position_error_m",1000,"mm"),("orientation_error_deg",1,"degrees")]:
    n=np.array([float(s[p,"N","loading"][field])*mult for p in pairs])
    a=np.array([float(s[p,"A","loading"][field])*mult for p in pairs])
    delta=a-n
    means=delta[indices].mean(axis=1)
    lo,hi=np.quantile(means,[.025,.975])
    paired_stats[field]={"unit":unit,"mean_difference":float(delta.mean()),"lower95":float(lo),"upper95":float(hi),
        "native_mean":float(n.mean()),"assisted_mean":float(a.mean()),"native_median":float(np.median(n)),
        "assisted_median":float(np.median(a)),"native_max":float(n.max()),"assisted_max":float(a.max()),
        "improved":int((delta<0).sum()),"worsened":int((delta>0).sum()),"tied":int((delta==0).sum())}
assert abs(paired_stats["position_error_m"]["mean_difference"]+7.666686425489645)<1e-9

fig,axs=plt.subplots(3,2,figsize=(7.1,5.8),gridspec_kw={"height_ratios":[1,1.3,.8],"wspace":.34,"hspace":.76})
for y,m,label,color,marker in [(1,"N","Native",BLUE,"o"),(0,"A","Assisted",ORANGE,"s")]:
    z=cis[m];v=100*z["estimate"]
    axs[0,0].errorbar(v,y,xerr=[[v-100*z["lower95"]],[100*z["upper95"]-v]],fmt=marker,ms=6,color=color,capsize=3,lw=1.5)
    axs[0,0].text(2,y+.18,f'{z["successes"]}/36 ({v:.1f}%)',fontsize=8)
axs[0,0].set(xlim=(0,102),ylim=(-.4,1.55),yticks=[0,1],yticklabels=["Assisted","Native"],xticks=[0,25,50,75,100],xlabel="Qualified workflow success (%)")
axs[0,0].set_title("a   Primary outcome",loc="left",fontweight="bold")
axs[0,0].grid(axis="x",color="#e6ebee",lw=.6)
colors={(True,True):TEAL,(False,True):ORANGE,(True,False):BLUE,(False,False):"#9b5060"}
counts={k:0 for k in colors}
for i,p in enumerate(pairs):
    row,col=divmod(i,12);state=(outcomes[p,"N"],outcomes[p,"A"]);counts[state]+=1
    axs[0,1].add_patch(Rectangle((col,row),.92,.82,facecolor=colors[state],edgecolor="black" if p.endswith("draw024") else "white",lw=1.6 if p.endswith("draw024") else .4))
    axs[0,1].text(col+.46,row+.41,f"{i+1:02d}",ha="center",va="center",color="white",fontsize=6.5)
assert list(counts.values())==[24,7,1,4]
axs[0,1].set(xlim=(-.05,12),ylim=(3.5,-.15));axs[0,1].axis("off")
axs[0,1].set_title("b   All paired outcomes",loc="left",fontweight="bold")
axs[0,1].legend(handles=[Patch(color=colors[k],label=label) for k,label in
 [((True,True),"Both: 24"),((False,True),"Assisted only: 7"),((True,False),"Native only: 1"),((False,False),"Neither: 4")]],
 frameon=False,ncol=2,fontsize=7,loc="lower center",bbox_to_anchor=(.48,-.18),columnspacing=.8,handlelength=.8)
for col,field,mult,unit,threshold,letter,title in [
 (0,"position_error_m",1000,"mm",15,"c","Loading position error"),
 (1,"orientation_error_deg",1,"degrees",10,"d","Loading yaw error")]:
    ax=axs[1,col]
    for m,name,color in [("N","Native",BLUE),("A","Assisted",ORANGE)]:
        vals=sorted(float(s[p,m,"loading"][field])*mult for p in pairs)
        y=np.arange(1,37)/36*100
        ax.step([0]+vals,[0]+list(y),where="post",color=color,lw=1.4,label=name)
        ax.scatter(vals,y,s=7,color=color,zorder=3)
    ax.axvline(threshold,color=GREY,ls="--",lw=.8)
    ax.set_xscale("symlog",linthresh=15 if col==0 else 2,linscale=1.2)
    ax.set(xlim=(0,380 if col==0 else 140),ylim=(0,103),yticks=[0,25,50,75,100],xlabel=f"Endpoint error ({unit}, symlog)")
    ticks=[0,5,15,100,350] if col==0 else [0,1,2,10,100]
    ax.set_xticks(ticks,labels=[str(t) for t in ticks])
    ax.set_title(f"{letter}   {title}",loc="left",fontweight="bold")
    ax.grid(axis="y",color="#e6ebee",lw=.6)
    if col==0:ax.set_ylabel("Fraction of endpoints (%)")
    else:ax.legend(frameon=False,fontsize=7,loc="lower right")
    z=paired_stats[field];a=axs[2,col];v=z["mean_difference"]
    a.axvline(0,color=GREY,ls="--",lw=.8)
    a.errorbar(v,.35,xerr=[[v-z["lower95"]],[z["upper95"]-v]],fmt="D",color=ORANGE,ms=6,capsize=4,lw=1.8)
    a.set(ylim=(0,1),yticks=[],xlabel=f"Assisted minus native ({unit})")
    a.spines["left"].set_visible(False)
    left=min(0,z["lower95"]);right=max(0,z["upper95"]);pad=max((right-left)*.14,.1)
    a.set_xlim(left-pad,right+pad)
    a.text(.5,.91,f'{v:.2f} [{z["lower95"]:.2f}, {z["upper95"]:.2f}]',transform=a.transAxes,ha="center",va="top",fontsize=8)
    a.set_title(f'{"e" if col==0 else "f"}   Paired mean change',loc="left",fontweight="bold")
fig.subplots_adjust(left=.105,right=.985,bottom=.07,top=.95)
save(fig,"continuous_results")
manifest={
 "workflow_counts":cis,
 "paired_loading_errors":paired_stats,
 "paired_bootstrap":{"replicates":10000,"seed":20261016,"unit":"complete scenario-seed pair","method":"percentile interval of paired mean differences","status":"exploratory secondary analysis","retains_upstream_discrepant_pair":True},
 "goal_intervals":{"source":"evaluation-groups.json","method":"retained source-family percentile bootstrap","families":6,"replicates":10000,"zero_cells":"degenerate intervals not plotted"},
 "sources":[{"file":p.name,"sha256":hashlib.sha256(p.read_bytes()).hexdigest()} for p in sorted(DATA.iterdir()) if p.is_file()],
 "new_experiments":False
}
(DATA/"figure_validation.json").write_text(json.dumps(manifest,indent=2)+"\n")
print(json.dumps({"confidence_intervals":cis,"paired_errors":paired_stats},indent=2))
